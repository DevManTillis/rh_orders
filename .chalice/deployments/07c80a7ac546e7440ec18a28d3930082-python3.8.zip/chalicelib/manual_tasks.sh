#!/bin/bash
# home_dir = os.path.expanduser("~")
home_dir = os.path.expanduser("/tmp")
