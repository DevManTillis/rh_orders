import datetime
import sys
import pyotp
import os
from dotenv import load_dotenv
load_dotenv()
import requests

import robin_stocks as r



totp  = pyotp.TOTP(os.environ['robin_mfa']).now()
print("Current OTP:", totp)
login = r.login(os.environ['robin_username'], os.environ['robin_password'], store_session=True, mfa_code=totp)
# print("login data is ", login)

print("===")
print("running test at {}".format(datetime.datetime.now()))
print("===")
info = r.get_latest_price('AAPL', priceType='cheese')
print(info)

print(next(iter(r.get_latest_price('aapl', 'ask_price', False)), 0.00))

### next(iter(list), 'empty')


# for key, value in info.items():
#     print(key, value)


# info = r.delete_symbols_from_watchlist(['fb','qd'],'Default')
# print(info)

# order = r.orders.order_buy_trailing_stop('BA', 1, 10, trailType='percentage', timeInForce='gtc')
# info = r.get_crypto_historicals('btc')
# print(info)
# info = r.get_stock_historicals(['aapl'])
# info = r.get_option_historicals('spy', '2020-07-01', '307', 'call', 'hour', 'day', 'regular')
# info = r.find_tradable_options_for_stock('spy',strikePrice='307',expirationDate='2020-07-01',optionType='call',info='type')
# info = r.find_options_by_expiration(['aapl'],'2020-07-02')
# info = r.find_options_by_strike(['aapl', 'spy'],'290')
# info = r.find_options_by_expiration_and_strike(['spy', 'aapl'],'2020-07-02', '300')
# info = r.find_options_by_specific_profitability(['fb','aapl'], expirationDate='2020-07-02', optionType='call')
# info = r.get_option_market_data(['fb','aapl'],'2020-07-02',300)
# print(info)
# print(len(info))
# for items in info:
#     print(items)
# print(info['open_price'])
